﻿using ExcelDna.Integration;
using ExcelDna.ComInterop;
using System.Runtime.InteropServices;

[ComVisible(true)]
[ClassInterface(ClassInterfaceType.AutoDispatch)]
[ProgId("ComAddin.FunctionLibrary")]
public class AccessibleFunctions
{
	public double add(double x, double y)
	{
		return x + y;
	}
}

[ComVisible(false)]
class ExcelAddin : IExcelAddIn
{
	public void AutoOpen()
	{
		ComServer.DllRegisterServer();
	}
	public void AutoClose()
	{
		ComServer.DllUnregisterServer();
	}
}